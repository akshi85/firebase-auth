import React from 'react';
import Login from './components/Login';
import './app.css';

const App = () => {
  return (
    <div>
      <Login />
    </div>
  );
};

export default App;
